# Create a variable called 'name' that holds a string

# Create a variable called 'country' that holds a string

# Create a variable called 'age' that holds an integer

# Create a variable called 'hourly_wage' that holds an integer

# Calculate the daily wage for the user

# Create a variable called 'satisfied' that holds a boolean

# Print out "Hello <name>!"

# Print out what country the user entered

# Print out the user's age

# With an f-string, print out the daily wage that was calculated

# With an f-string, print out whether the users were satisfied
