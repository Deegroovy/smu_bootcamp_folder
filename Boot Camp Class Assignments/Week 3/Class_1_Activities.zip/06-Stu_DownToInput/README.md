# Down to Input

In this activity, you store inputs from the command line and run code based on those inputs.

## Instructions

* Create two different variables, one to take the input of your first name and one for your neighbor’s first name.

* Create two more inputs to ask how many months you and your neighbor have been coding.

* Finally, display a result with both your names and the total amount of months coding.

—

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
